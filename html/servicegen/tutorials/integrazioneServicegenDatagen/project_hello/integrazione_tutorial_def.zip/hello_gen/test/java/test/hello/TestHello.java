package test.hello;

import it.csi.csi.wrapper.SystemException;
import it.csi.csi.wrapper.UnrecoverableException;
import it.csi.hello.hello.dto.hello.*;
import it.csi.hello.hello.interfacecsi.hello.*;
import it.csi.hello.hello.exception.hello.*;
import it.csi.csi.util.xml.*;
import it.csi.csi.porte.*;
import it.csi.csi.porte.proxy.*;
import javax.sql.DataSource;
import org.apache.log4j.*;
import junit.framework.TestCase;

/*PROTECTED REGION ID(R332542671) ENABLED START*/
/// inserire qui eventuali import aggiuntive
/*PROTECTED REGION END*/

/**
 * @generated
 */
public class TestHello extends TestCase {

	/**
	 * @generated
	 */
	public static final String LOGGER_PREFIX = "hello";

	/**
	 * @generated
	 */
	it.csi.hello.hello.interfacecsi.hello.HelloSrv pd = null;

	/**
	 * @generated
	 */
	public void setUp() throws Exception {
		InfoPortaDelegata info = PDConfigReader
				.read("test/java/test/hello/defpd_hello.xml");
		pd = (it.csi.hello.hello.interfacecsi.hello.HelloSrv) PDProxy
				.newInstance(info);
	}

	/*PROTECTED REGION ID(R1628178477) ENABLED START*/
	// inserire qui la definizione di variabili locali, costanti da usare nel test.
	// non verranno sovrascritte da successive rigenerazioni
	/*PROTECTED REGION END*/

	/// Implementazione operazioni esposte dal servizio

	/**
	 * @generated
	 */
	public void testOperationSayHello() {
		/*PROTECTED REGION ID(R-300924991) ENABLED START*/
		/// inserire qui la logica di test per l'operazione.
		/// il codice sar� preservato per successive rigenerazioni
		/*PROTECTED REGION END*/
	}

	/**
	 * @generated
	 */
	protected Logger getLogger(String subsystem) {
		if (subsystem != null)
			return Logger.getLogger(LOGGER_PREFIX + "." + subsystem);
		else
			return Logger.getLogger(LOGGER_PREFIX);
	}

	/// eventuali metodi aggiuntivi
	/*PROTECTED REGION ID(R-1883219984) ENABLED START*/
	// inserire qui la dichiarazione di eventuali metodi aggiuntivi utili
	// per l'implementazione.
	// non verr� sovrascritto da successive rigenerazioni.
	/*PROTECTED REGION END*/
}
