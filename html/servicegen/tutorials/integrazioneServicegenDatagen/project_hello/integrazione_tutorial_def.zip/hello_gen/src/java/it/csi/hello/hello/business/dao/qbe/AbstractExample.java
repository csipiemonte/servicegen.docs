package it.csi.hello.hello.business.dao.qbe;

/**
 * 
 * @generated
 *
 */
public class AbstractExample {

}
