package it.csi.hello.hello.business.dao.hello.dao.impl;

import it.csi.hello.hello.business.dao.hello.dao.*;
import it.csi.hello.hello.business.dao.hello.dto.*;
import it.csi.hello.hello.business.dao.hello.qbe.*;
import it.csi.hello.hello.business.dao.hello.metadata.*;
import it.csi.hello.hello.business.dao.hello.exceptions.*;
import it.csi.hello.hello.business.dao.util.*;
import it.csi.hello.hello.business.dao.qbe.*;
import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import it.csi.util.performance.StopWatch;
import org.apache.log4j.Logger;
import java.util.Map;
import java.util.TreeMap;

/*PROTECTED REGION ID(R-154674951) ENABLED START*/
// aggiungere qui eventuali import custom. 
/*PROTECTED REGION END*/

/**
 * @generated
 */
public class HelloDaoImpl extends AbstractDAO
		implements
			ParameterizedRowMapper<HelloDto>,
			HelloDao {
	protected static Logger log = Logger.getLogger(Constants.APPLICATION_CODE);
	/**
	 * @generated
	 */
	protected NamedParameterJdbcTemplate jdbcTemplate;

	/**
	 * @generated
	 */
	public void setJdbcTemplate(NamedParameterJdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return HelloDto
	 * @generated
	 */
	public HelloDto mapRow(ResultSet rs, int row) throws SQLException {
		HelloDto dto = new HelloDto();
		dto = mapRow_internal(dto, rs, row);
		return dto;
	}

	/**
	 * Method 'mapRow_internal'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return HelloDto
	 * @generated
	 */
	public HelloDto mapRow_internal(HelloDto objectToFill, ResultSet rs, int row)
			throws SQLException {
		HelloDto dto = objectToFill;

		dto.setNome(rs.getString("NOME"));

		dto.setCognome(rs.getString("COGNOME"));

		dto.setCodiceFiscale(rs.getString("CODICE_FISCALE"));

		dto.setId(rs.getString("ID"));

		dto.setEmail(rs.getString("EMAIL"));

		dto.setSesso(rs.getString("SESSO"));

		dto.setRegioneResidenza(rs.getString("REGIONE_RESIDENZA"));

		dto.setProvinciaResidenza(rs.getString("PROVINCIA_RESIDENZA"));

		return dto;
	}

	protected HelloDaoRowMapper findAllRowMapper = new HelloDaoRowMapper(null);

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 * @generated
	 */
	public String getTableName() {
		return "ANAGRAFICA";
	}

	/** 
	 * Returns all rows from the ANAGRAFICA table that match the criteria ''.
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public List<HelloDto> findAll() throws HelloDaoException {
		final StringBuilder sql = new StringBuilder(
				"SELECT NOME,COGNOME,CODICE_FISCALE,ID,EMAIL,SESSO,REGIONE_RESIDENZA,PROVINCIA_RESIDENZA FROM "
						+ getTableName());

		MapSqlParameterSource params = new MapSqlParameterSource();

		List<HelloDto> list = null;

		StopWatch stopWatch = new StopWatch(Constants.APPLICATION_CODE);
		try {
			stopWatch.start();
			list = jdbcTemplate.query(sql.toString(), params, findAllRowMapper);

		} catch (RuntimeException ex) {
			log.error("[HelloDaoImpl::findAll] esecuzione query", ex);
			throw new HelloDaoException("Query failed", ex);
		} finally {
			stopWatch.dumpElapsed("HelloDaoImpl", "findAll",
					"esecuzione query", sql.toString());
			log.debug("[HelloDaoImpl::findAll] END");
		}

		return list;

	}

	/// flexible row mapper. 
	public class HelloDaoRowMapper
			implements
				org.springframework.jdbc.core.RowMapper {

		private java.util.HashMap<String, String> columnsToReadMap = new java.util.HashMap<String, String>();
		private boolean mapAllColumns = true;

		/**
		 * @param columnsToRead elenco delle colonne da includere nel mapping (per query
		 *        incomplete, esempio distinct, custom select...)
		 */
		public HelloDaoRowMapper(String[] columnsToRead) {
			if (columnsToRead != null) {
				mapAllColumns = false;
				for (int i = 0; i < columnsToRead.length; i++)
					columnsToReadMap.put(columnsToRead[i], columnsToRead[i]);
			}
		}

		/**
		 * Method 'mapRow'
		 * 
		 * @param rs
		 * @param row
		 * @throws SQLException
		 * @return HelloDto
		 * @generated
		 */
		public HelloDto mapRow(ResultSet rs, int row) throws SQLException {
			HelloDto dto = new HelloDto();
			dto = mapRow_internal(dto, rs, row);
			return dto;
		}

		/**
		 * Method 'mapRow_internal'
		 * 
		 * @param rs
		 * @param row
		 * @throws SQLException
		 * @return HelloDto
		 * @generated
		 */
		public HelloDto mapRow_internal(HelloDto objectToFill, ResultSet rs,
				int row) throws SQLException

		{
			HelloDto dto = objectToFill;

			if (mapAllColumns || columnsToReadMap.get("NOME") != null)
				dto.setNome(rs.getString("NOME"));

			if (mapAllColumns || columnsToReadMap.get("COGNOME") != null)
				dto.setCognome(rs.getString("COGNOME"));

			if (mapAllColumns || columnsToReadMap.get("CODICE_FISCALE") != null)
				dto.setCodiceFiscale(rs.getString("CODICE_FISCALE"));

			if (mapAllColumns || columnsToReadMap.get("ID") != null)
				dto.setId(rs.getString("ID"));

			if (mapAllColumns || columnsToReadMap.get("EMAIL") != null)
				dto.setEmail(rs.getString("EMAIL"));

			if (mapAllColumns || columnsToReadMap.get("SESSO") != null)
				dto.setSesso(rs.getString("SESSO"));

			if (mapAllColumns
					|| columnsToReadMap.get("REGIONE_RESIDENZA") != null)
				dto.setRegioneResidenza(rs.getString("REGIONE_RESIDENZA"));

			if (mapAllColumns
					|| columnsToReadMap.get("PROVINCIA_RESIDENZA") != null)
				dto.setProvinciaResidenza(rs.getString("PROVINCIA_RESIDENZA"));

			return dto;
		}

	}

}
