package it.csi.hello.hello.business.hello.custom;

import it.csi.hello.hello.business.dao.hello.dao.HelloDao;

public class CustomBean {

	private HelloDao helloDao;

	public void setHelloDao(HelloDao helloDao) {
		this.helloDao = helloDao;
	}

	public HelloDao getHelloDao() {
		return helloDao;
	}
	
}
