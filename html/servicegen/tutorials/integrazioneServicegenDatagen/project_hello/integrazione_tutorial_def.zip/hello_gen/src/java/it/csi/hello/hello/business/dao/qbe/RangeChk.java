package it.csi.hello.hello.business.dao.qbe;

/**
 * 
 * Verifica di appartenenza ad un range continuo 
 * @generated
 */
public class RangeChk extends FieldChk {

	/**
	 * @generated
	 */
	private Object _lowerBound;

	/**
	 * @generated
	 */
	private Object _upperBound;

	/**
	 * @generated
	 */
	private boolean _includeLB;

	/**
	 * @generated
	 */
	private boolean _includeUB;

	/**
	 * @param lowerBound l'estremo inferiore del range (se non specificato il check � a -infinito)
	 * @param upperBound l'estremo superiore del range (se non specificato il check � a +infinito)
	 * @param includeLB include o meno il lowerbound tra i valori ammessi
	 * @param includeUB include o meno l'upperbound tra i valori ammessi 
	 * @generated
	 */
	public RangeChk(Object lowerBound, Object upperBound, boolean includeLB,
			boolean includeUB) {
		assert lowerBound != null || upperBound != null;
		_lowerBound = lowerBound;
		_upperBound = upperBound;
		_includeLB = includeLB;
		_includeUB = includeUB;
	}

	/**
	 * @generated
	 */
	public Object getLowerBound() {
		return _lowerBound;
	}

	/**
	 * @generated
	 */
	public Object getUpperBound() {
		return _upperBound;
	}

	/**
	 * @generated
	 */
	public boolean isLBIncluded() {
		return _includeLB;
	}

	/**
	 * @generated
	 */
	public boolean isUBIncluded() {
		return _includeLB;
	}
}
