package it.csi.hello.hello.business.hello;

import java.rmi.*;
import javax.ejb.*;

/**
 * @generated
 */
public interface HelloHome extends EJBHome {
	/**
	 * @generated
	 */
	public HelloRemote create() throws RemoteException, CreateException;
}
