package it.csi.hello.hello.business.dao.hello.exceptions;

/**
 *
 * @generated
 */
public class HelloDaoException extends DaoException {
	/** 
	 * @param message
	 * @generated
	 */
	public HelloDaoException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 * @generated
	 */
	public HelloDaoException(String message, Throwable cause) {
		super(message, cause);
	}

}
