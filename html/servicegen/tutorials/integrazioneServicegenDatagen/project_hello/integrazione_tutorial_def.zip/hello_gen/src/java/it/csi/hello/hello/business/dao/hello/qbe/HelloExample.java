package it.csi.hello.hello.business.dao.hello.qbe;

import it.csi.hello.hello.business.dao.hello.dao.*;
import it.csi.hello.hello.business.dao.hello.dto.*;
import it.csi.hello.hello.business.dao.qbe.*;
import it.csi.hello.hello.business.dao.hello.exceptions.*;
import java.io.Serializable;
import java.util.*;

/**
 * @generated
 */
public class HelloExample extends AbstractExample {

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _nome;

	/**
	 * @generated
	 */
	public void setNome(it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_nome = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getNome() {
		return _nome;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _cognome;

	/**
	 * @generated
	 */
	public void setCognome(it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_cognome = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getCognome() {
		return _cognome;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _codiceFiscale;

	/**
	 * @generated
	 */
	public void setCodiceFiscale(
			it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_codiceFiscale = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getCodiceFiscale() {
		return _codiceFiscale;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _id;

	/**
	 * @generated
	 */
	public void setId(it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_id = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getId() {
		return _id;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _email;

	/**
	 * @generated
	 */
	public void setEmail(it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_email = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getEmail() {
		return _email;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _sesso;

	/**
	 * @generated
	 */
	public void setSesso(it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_sesso = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getSesso() {
		return _sesso;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _regioneResidenza;

	/**
	 * @generated
	 */
	public void setRegioneResidenza(
			it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_regioneResidenza = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getRegioneResidenza() {
		return _regioneResidenza;
	}

	/**
	 * @generated
	 */
	private it.csi.hello.hello.business.dao.qbe.FieldChk _provinciaResidenza;

	/**
	 * @generated
	 */
	public void setProvinciaResidenza(
			it.csi.hello.hello.business.dao.qbe.FieldChk chk) {
		_provinciaResidenza = chk;
	}

	/**
	 * @generated
	 */
	public it.csi.hello.hello.business.dao.qbe.FieldChk getProvinciaResidenza() {
		return _provinciaResidenza;
	}

}
