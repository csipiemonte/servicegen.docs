package it.csi.hello.hello.business.dao.qbe;

/**
 * 
 * Verifica di appartenenza ad un insieme discreto di valori costanti 
 * @generated
 */
public class InSetChk extends FieldChk {

	/**
	 * @generated
	 */
	private Object[] _items;

	/**
	 * 
	 * @param items insieme degli elementi dell'insieme di riferimento 
	 * @generated
	 */
	public InSetChk(Object[] items) {
		assert items != null && items.length > 0;
		_items = items;
	}
	/**
	 * @generated
	 */
	public Object[] getItems() {
		return _items;
	}
}
