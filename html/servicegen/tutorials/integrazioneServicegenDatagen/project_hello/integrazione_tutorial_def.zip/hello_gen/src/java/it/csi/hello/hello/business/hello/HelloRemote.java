package it.csi.hello.hello.business.hello;

import it.csi.hello.hello.dto.hello.*;
import it.csi.hello.hello.exception.hello.*;

/**
 * Interfaccia remota dell'EJB che implementa il servizio hello.
 * @generated
 */
public interface HelloRemote extends javax.ejb.EJBObject {

	/**
	 * @generated
	 */
	public java.lang.String sayHello(

	java.lang.String nome,

	java.lang.String cognome

	) throws it.csi.csi.wrapper.CSIException,
			it.csi.csi.wrapper.SystemException,
			it.csi.csi.wrapper.UnrecoverableException, java.rmi.RemoteException;

}
