package it.csi.hello.hello.business.dao.hello.dto;

import it.csi.hello.hello.business.dao.hello.dao.*;
import it.csi.hello.hello.business.dao.hello.exceptions.*;
import java.io.Serializable;
import java.util.*;

/**
 * @generated
 */
public class HelloDto implements Serializable {

	/**
	 * @generated
	 */
	private String _nome;

	/**
	 * @generated
	 */
	public void setNome(String val) {
		_nome = val;
	}

	/**
	 * @generated
	 */
	public String getNome() {
		return _nome;
	}

	/**
	 * @generated
	 */
	private String _cognome;

	/**
	 * @generated
	 */
	public void setCognome(String val) {
		_cognome = val;
	}

	/**
	 * @generated
	 */
	public String getCognome() {
		return _cognome;
	}

	/**
	 * @generated
	 */
	private String _codiceFiscale;

	/**
	 * @generated
	 */
	public void setCodiceFiscale(String val) {
		_codiceFiscale = val;
	}

	/**
	 * @generated
	 */
	public String getCodiceFiscale() {
		return _codiceFiscale;
	}

	/**
	 * @generated
	 */
	private String _id;

	/**
	 * @generated
	 */
	public void setId(String val) {
		_id = val;
	}

	/**
	 * @generated
	 */
	public String getId() {
		return _id;
	}

	/**
	 * @generated
	 */
	private String _email;

	/**
	 * @generated
	 */
	public void setEmail(String val) {
		_email = val;
	}

	/**
	 * @generated
	 */
	public String getEmail() {
		return _email;
	}

	/**
	 * @generated
	 */
	private String _sesso;

	/**
	 * @generated
	 */
	public void setSesso(String val) {
		_sesso = val;
	}

	/**
	 * @generated
	 */
	public String getSesso() {
		return _sesso;
	}

	/**
	 * @generated
	 */
	private String _regioneResidenza;

	/**
	 * @generated
	 */
	public void setRegioneResidenza(String val) {
		_regioneResidenza = val;
	}

	/**
	 * @generated
	 */
	public String getRegioneResidenza() {
		return _regioneResidenza;
	}

	/**
	 * @generated
	 */
	private String _provinciaResidenza;

	/**
	 * @generated
	 */
	public void setProvinciaResidenza(String val) {
		_provinciaResidenza = val;
	}

	/**
	 * @generated
	 */
	public String getProvinciaResidenza() {
		return _provinciaResidenza;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 * @generated
	 */
	public boolean equals(Object _other) {
		// TODO
		return super.equals(_other);
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 * @generated
	 */
	public int hashCode() {
		// TODO
		return super.hashCode();
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 * @generated
	 */
	public String toString() {
		// TODO
		return super.toString();
	}

}
