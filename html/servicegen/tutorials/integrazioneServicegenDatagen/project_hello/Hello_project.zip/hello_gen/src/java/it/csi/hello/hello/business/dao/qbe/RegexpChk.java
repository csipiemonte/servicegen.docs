package it.csi.hello.hello.business.dao.qbe;

/**
 * 
 * Verifica di conformita' con una regular expression 
 * @generated
 */
public class RegexpChk extends FieldChk {

	/**
	 * @generated
	 */
	private String _regexp;

	/**
	 * @param equalsTo valore di confronto 
	 * @generated
	 */
	public RegexpChk(String regexp) {
		assert regexp != null && regexp.length() > 0;
		_regexp = regexp;
	}

	/**
	 * @generated
	 */
	public String getRegexp() {
		return _regexp;
	}
}
