package it.csi.hello.hello.business.dao.util;
/**
 * @generated
 */
public final class Constants {
	/**
	 * identificativo dell'applicativo.
	 */
	public static final String APPLICATION_CODE = "hello";

	/*PROTECTED REGION ID(R-1074371075) ENABLED START*/

	/*PROTECTED REGION END*/
}
