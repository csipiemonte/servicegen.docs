package it.csi.hello.hello.business.dao.metadata;

import java.io.*;
import java.sql.*;

/**
 * Interface for DAO Metadata.
 *
 * @generated
 */
public interface DAOMetadata {

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 * @generated
	 */
	public abstract String getTableName();

	/**
	 * Method 'getColumnName'
	 * 
	 * @param propName
	 * @return String
	 * @generated
	 */
	public abstract String getColumnName(String propName);

	/**
	 * Method 'getColumnNames'
	 * 
	 * @return String[]
	 * @generated
	 */
	public abstract String[] getColumnNames();

}
