package it.csi.hello.hello.business.hello.spring.startup;

import org.springframework.beans.factory.access.BeanFactoryReference;
import org.springframework.context.access.ContextBeanFactoryReference;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @generated
 */
public class LoadStartupService implements LoadStartupServiceMBean {

	/** Spring BeanFactory that provides the namespace for this EJB 
	 * @generated
	 */
	private static BeanFactoryReference beanFactoryReference;

	/**
	 * @generated
	 */
	private String message = "problems....";

	/**
	 * @generated
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @generated
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @generated
	 */
	public void printMessage() {
		System.out.println(message);
	}

	/**
	 * @generated
	 */
	public void start() throws Exception {
		System.out.println("Messaggio di avvio MBEAN=" + message);
		try {
			String[] springCfg = new String[]{"META-INF/helloBeanContext.xml",
					"META-INF/helloDao-beans.xml"};
			ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(
					springCfg);
			beanFactoryReference = new ContextBeanFactoryReference(ctx);

		} catch (Exception e) {
			System.out.println("Attenzione si � verificata un'eccezione: " + e);
		}
		System.out.println("Chiamata da MBEAN eseguita!!!!");
	}

	/**
	 * @generated
	 */
	public static Object getBean(String beanName) {

		Object beanObject = null;

		try {

			beanObject = beanFactoryReference.getFactory().getBean(beanName);

		} catch (Exception e) {
			System.out.println("Attenzione si � verificata un'eccezione: " + e);
		}

		return beanObject;
	}

	/**
	 * @generated
	 */
	public void stop() {
		System.out.println("Messaggio di stop MBEAN=" + message);
	}
}
