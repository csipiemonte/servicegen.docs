package it.csi.hello.hello.business.dao.qbe;

/**
 * 
 * Verifica di valorizzazione del campo.
 * @generated
 */
public class NullChk extends FieldChk {

	/** 
	 * @generated
	 */
	public NullChk() {
	}
}
