package it.csi.hello.hello.business.dao.hello.dao;

import it.csi.hello.hello.business.dao.hello.dao.*;
import it.csi.hello.hello.business.dao.hello.dto.*;
import it.csi.hello.hello.business.dao.hello.qbe.*;
import it.csi.hello.hello.business.dao.hello.metadata.*;
import it.csi.hello.hello.business.dao.hello.exceptions.*;
import it.csi.hello.hello.business.dao.util.*;
import it.csi.hello.hello.business.dao.qbe.*;
import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @generated
 */
public interface HelloDao {

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return HelloDto
	 * @generated
	 */
	public HelloDto mapRow(ResultSet rs, int row) throws SQLException;

	/**
	 * Method 'mapRow_internal'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return HelloDto
	 * @generated
	 */
	public HelloDto mapRow_internal(HelloDto objectToFill, ResultSet rs, int row)
			throws SQLException;

	/** 
	 * Returns all rows from the ANAGRAFICA table that match the criteria ''.
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public List<HelloDto> findAll() throws HelloDaoException;

}
