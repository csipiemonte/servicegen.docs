package it.csi.hello.hello.business.hello;

import it.csi.hello.hello.dto.hello.*;
import it.csi.hello.hello.exception.hello.*;

/**
 * Interfaccia locale dell'EJB che implementa il servizio hello.
 * @generated
 */
public interface HelloLocal
		extends
			javax.ejb.EJBLocalObject,
			it.csi.hello.hello.interfacecsi.hello.HelloSrv {

}
