package it.csi.hello.hello.business.hello;

import java.rmi.*;
import javax.ejb.*;

/**
 * @generated
 */
public interface HelloLocalHome extends EJBLocalHome {
	/**
	 * @generated
	 */
	public HelloLocal create() throws CreateException;
}
