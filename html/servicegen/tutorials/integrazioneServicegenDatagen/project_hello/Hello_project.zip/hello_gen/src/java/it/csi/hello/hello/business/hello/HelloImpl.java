package it.csi.hello.hello.business.hello;

import it.csi.csi.wrapper.*;

import it.csi.hello.hello.dto.hello.*;
import it.csi.hello.hello.interfacecsi.hello.*;
import it.csi.hello.hello.exception.hello.*;

import javax.sql.DataSource;
import org.apache.log4j.*;

/*PROTECTED REGION ID(R1375669789) ENABLED START*/
// aggiungere qui eventuali import aggiuntive.
// verranno preservate in rigenerazioni successive del progetto
/*PROTECTED REGION END*/

/**
 * @generated
 */
public class HelloImpl {
	/**
	 * @generated
	 */
	public static final String LOGGER_PREFIX = "hello";

	/*PROTECTED REGION ID(R8738107) ENABLED START*/
	// inserire qui la definizione di varibili locale o costanti dell'implementazione.
	// non verranno sovrascritte da successive rigenerazioni
	/*PROTECTED REGION END*/

	/// Implementazione operazioni esposte dal servizio

	/**
	 * @generated
	 */
	public java.lang.String sayHello(

	java.lang.String nome,

	java.lang.String cognome

	) throws it.csi.csi.wrapper.CSIException,
			it.csi.csi.wrapper.SystemException,
			it.csi.csi.wrapper.UnrecoverableException

	{
		Logger logger = getLogger(null);
		logger.debug("[HelloImpl::sayHello] - START");

		it.csi.util.performance.StopWatch watcher = new it.csi.util.performance.StopWatch(
				"hello");
		// inizio misurazione
		watcher.start();

		/*PROTECTED REGION ID(R1210972425) ENABLED START*/
		// inserire qui la dichiarazione di variabili locali al metodo
		// non verr� sovrascritto nelle successive rigenerazioni
		/*PROTECTED REGION END*/
		try {
			/*PROTECTED REGION ID(R906512809) ENABLED START*/
			// inserire qui il codice di implementazione del metodo 'sayHello'.
			// non verr� sovrascritto nelle successive rigenerazioni

			return null;

			/*PROTECTED REGION END*/
		}

		catch (Throwable ex) {
			if (CSIException.class.isAssignableFrom(ex.getClass())) {
				logger.error(
						"[HelloImpl::sayHello] - Errore CSI occorso durante l'esecuzione del metodo:"
								+ ex, ex);
				throw (CSIException) ex;
			} else {
				logger.error(
						"[HelloImpl::sayHello] - Errore imprevisto occorso durante l'esecuzione del metodo:"
								+ ex, ex);
				throw new UnrecoverableException(
						"Errore imprevisto occorso durante l'esecuzione del metodo:"
								+ ex, ex);
			}
		} finally {
			// fine misurazione
			watcher.stop();
			watcher.dumpElapsed("HelloImpl", "sayHello()",
					"invocazione servizio [hello]::[sayHello]",
					"(valore input omesso)");
			logger.debug("[HelloImpl::sayHello] - END");
		}
	}

	/// inizializzazione
	/**
	 * @generated
	 */
	public void init(Object initOptions) {
		/*PROTECTED REGION ID(R1249474434) ENABLED START*/
		// inserire qui il codice di inizializzazione della implementazione
		// non verr� sovrascritto da successive rigenerazioni
		/*PROTECTED REGION END*/
	}

	/**
	 * @generated
	 */
	protected Logger getLogger(String subsystem) {
		if (subsystem != null)
			return Logger.getLogger(LOGGER_PREFIX + "." + subsystem);
		else
			return Logger.getLogger(LOGGER_PREFIX);
	}

	/// eventuali metodi aggiuntivi
	/*PROTECTED REGION ID(R464611664) ENABLED START*/
	// inserire qui la dichiarazione di eventuali metodi aggiuntivi utili
	// per l'implementazione.
	// non verr� sovrascritto da successive rigenerazioni.
	/*PROTECTED REGION END*/
}
