package it.csi.hello.hello.business.dao.qbe;

/**
 * 
 * Verifica di uguaglianza del valore del campo con un valore costante. 
 * @generated
 */
public class EqChk extends FieldChk {

	private Object _exVal;
	private boolean _ignoreCase = false;

	/**
	 * @param equalsTo valore di confronto 
	 * @generated
	 */
	public EqChk(Object equalsTo) {
		assert equalsTo != null;
		_exVal = equalsTo;
		_ignoreCase = false;
	}

	/**
	 * @generated
	 */
	public boolean valueHasWildcards() {
		if (_exVal == null || !(_exVal instanceof String))
			return false;
		else {
			return (((String) _exVal).indexOf("%") > -1);
		}
	}

	/**
	 * @param equalsTo valore di confronto 
	 * @param ignoreCase ignora il case in caso di tipo stringa
	 * @generated
	 */
	public EqChk(Object equalsTo, boolean ignoreCase) {
		assert equalsTo != null;
		_exVal = equalsTo;
		_ignoreCase = ignoreCase;
	}
	/**
	 * @generated
	 */
	public Object getExVal() {
		return _exVal;
	}

	/**
	 * @generated
	 */
	public boolean isIgnoreCase() {
		return _ignoreCase;
	}
}
