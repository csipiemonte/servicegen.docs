package it.csi.hello.hello.business.hello.spring.startup;

/**
 * @generated
 */
public interface LoadStartupServiceMBean {
	/**
	 * @generated
	 */
	String getMessage();

	/**
	 * @generated
	 */
	void setMessage(String message);

	/**
	 * @generated
	 */
	void printMessage();

	/**
	 * @generated
	 */
	void start() throws Exception;

	/**
	 * @generated
	 */
	void stop();
}
