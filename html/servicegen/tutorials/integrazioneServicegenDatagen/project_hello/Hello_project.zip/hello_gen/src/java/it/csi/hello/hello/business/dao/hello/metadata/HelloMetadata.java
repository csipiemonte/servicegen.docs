package it.csi.hello.hello.business.dao.hello.metadata;

import it.csi.hello.hello.business.dao.hello.dto.*;
import it.csi.hello.hello.business.dao.metadata.*;
import java.util.List;

/**
 * @generated
 */
public class HelloMetadata implements DAOMetadata {

	private String[] columnNames;

	public HelloMetadata() {
		columnNames = new String[]{"NOME", "COGNOME", "CODICE_FISCALE", "ID",
				"EMAIL", "SESSO", "REGIONE_RESIDENZA", "PROVINCIA_RESIDENZA"};
	}

	public HelloMetadata(String[] columnNames) {
		this.columnNames = columnNames;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 * @generated
	 */
	public String getTableName() {
		return "ANAGRAFICA";
	}

	/**
	 * Method 'getColumnName'
	 * 
	 * @param propName
	 * @return String
	 * @generated
	 */
	public String getColumnName(String propName) {
		if ("nome".equalsIgnoreCase(propName)) {
			return "NOME";
		}
		if ("cognome".equalsIgnoreCase(propName)) {
			return "COGNOME";
		}
		if ("codiceFiscale".equalsIgnoreCase(propName)) {
			return "CODICE_FISCALE";
		}
		if ("id".equalsIgnoreCase(propName)) {
			return "ID";
		}
		if ("email".equalsIgnoreCase(propName)) {
			return "EMAIL";
		}
		if ("sesso".equalsIgnoreCase(propName)) {
			return "SESSO";
		}
		if ("regioneResidenza".equalsIgnoreCase(propName)) {
			return "REGIONE_RESIDENZA";
		}
		if ("provinciaResidenza".equalsIgnoreCase(propName)) {
			return "PROVINCIA_RESIDENZA";
		}
		/// se non trovato
		throw new IllegalArgumentException("proprieta' " + propName
				+ " non trovata per il DTO HelloDto");
	}

	/**
	 * Method 'getColumnNames'
	 * 
	 * @return String[]
	 * @generated
	 */
	public String[] getColumnNames() {
		return this.columnNames;
	}

}
