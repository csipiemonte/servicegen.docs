package it.csi.hello.hello.business.hello.spring;

/**
 * 
 * @generated
 *
 */
public class SpringBeanLocator {

	/**
	 * @generated
	 */
	public static Object getBean(String beanName) {
		return it.csi.hello.hello.business.hello.spring.startup.LoadStartupService
				.getBean(beanName);

	}
}
